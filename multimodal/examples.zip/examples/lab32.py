"""Run multimodal lab 32 from the complete package."""
from run_lab import main
if __name__=="__main__":main("32")
