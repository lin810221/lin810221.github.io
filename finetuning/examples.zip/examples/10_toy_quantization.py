"""Experiment 10: toy quantization. Run from this directory."""
from finetune_core import cli

if __name__ == "__main__":
    cli(10)
